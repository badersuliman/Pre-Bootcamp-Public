import React, {useState} from 'react';
import {navigate} from '@reach/router';


export default props => {
    const {initialName, onSubmitProp} = props;
    const [name, setName] = useState(initialName);
    const [errors, setErrors] = useState([]); 
    const onSubmitHandler = (e) => {
        e.preventDefault();
        onSubmitProp({name});
    }
    return (
        <div>
            <form onSubmit={onSubmitHandler}>
            <p>
                <label>First Name</label><br/>
                <input type="text" onChange={(e)=>setName(e.target.value)} value={name}/>
            </p>
           
            <input type="submit"/>
        </form>
        </div>
    )
}